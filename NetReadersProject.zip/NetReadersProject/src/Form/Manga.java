/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Form;

/**
 *
 * @author ACER
 */
public class Manga {
    public String title;
    public String chapters;
    public String genre;
    public String status;
    public String file;

    public Manga(String title, String chapters, String genre, String status, String file) {
        this.title = title;
        this.chapters = chapters;
        this.genre = genre;
        this.status = status;
        this.file = file;
    }
    
    
    
    
}
